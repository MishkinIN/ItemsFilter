﻿// ****************************************************************************
// <author>mishkin Ivan</author>
// <email>Mishkin_Ivan@mail.ru</email>
// <date>28.01.2015</date>
// <project>ItemsFilter</project>
// <license> GNU General Public License version 3 (GPLv3) </license>
// ****************************************************************************
using System.Windows.Controls;

namespace Northwind.NET.Sample.View {
    /// <summary>
    /// Interaction logic for Products.xaml
    /// </summary>
    public partial class ProductsView : UserControl {
        public ProductsView() {
            InitializeComponent();
        }

        //private void UserControl_Loaded(object sender, RoutedEventArgs e) {
        //    DataContext = Workspace.This.Products;
        //}
    }
}
