﻿using BolapanControl.ItemsFilter.Initializer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Northwind.NET.Sample.ViewModel {
    public class FilterInitializersManager : BolapanControl.ItemsFilter.Initializer.FilterInitializersManager {
    }
}
